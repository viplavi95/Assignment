import org.testng.annotations.Test;

import Logic.LaunchBrowsers;
import Logic.assignment_5;
import Logic.assignment_2;
import Logic.assignment_3;
import Logic.assignment_4;
import Logic.assignment_1;
import Pages.assignment3_page;
import Pages.practice_automation;
import Pages.assignment1_page;

public class VootHome extends LaunchBrowsers {
	
    @Test
    public void homePagevalidation() throws InterruptedException{
       
    	
    	
    	// assignment_1  ==http://practice.automationtesting.in/  
    	
    	//assignment_1.myaccount();
    	
    //	
        //assignment_2=//http://automationpractice.com/index.php
    	
    	
    	//assignment_2.signin();

       
    	//assignment_3 =//http://automationpractice.com/index.php
    	
        //assignment_3.contact_us();
   
    	
    	//assignment_4
    	
    	
    	 //assignment_4.iframes();
    	 assignment_4.single_frame();
    	  
    	  
    	//assignment5
         //assignment_5.anz();
    	
    
    }
    
    

}
