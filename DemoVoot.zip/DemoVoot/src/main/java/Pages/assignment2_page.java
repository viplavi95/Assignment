package Pages;
import org.openqa.selenium.By;

public class assignment2_page {
	
	    
	     public static By  signin_xpath= By.xpath("//a[normalize-space()='Sign in']");
	    public static By  E_mail_form_address=By.xpath("//input[@id='email_create']");
		public static By create_account_button=By.xpath("//span[normalize-space()='Create an account']");
	     
	     
		 public static By mr_button= By.xpath("//input[@id='id_gender1']");
		 public static By first_name_form=By.xpath("//input[@id='customer_firstname']");
		 
		 public static By last_name=By.xpath("//input[@id='customer_firstname']");
		 
		 public static By objMail = By.xpath("//input[@id='email']");
			public static By objPass = By.xpath("//input[@id='passwd']");
			public static By objDrop1 = By.xpath("//select[@id='days']");  
			public static By objDrop2 = By.xpath("//select[@id='months']");
			public static By objDrop3 = By.xpath("//select[@id='years']");
			public static By objCheck1 = By.xpath("//input[@id='newsletter']");
			public static By objCheck2 = By.xpath("//input[@id='optin']");
			public static By objFName = By.xpath("//input[@id='firstname']");
			public static By objLName = By.xpath("//input[@id='lastname']");
			public static By objComp = By.xpath("//input[@id='company']");
			public static By objAddress = By.xpath("//input[@id='address1']");
			public static By objAddressL2 = By.xpath("//input[@id='address2']");
			public static By objCity = By.xpath("//input[@id='city']");
			public static By objDrop4 = By.xpath("//select[@id='id_state']");
			public static By objPIN = By.xpath("//input[@id='postcode']");
			public static By objDrop5 = By.xpath("//select[@id='id_country']");
			public static By objAddInfo = By.xpath("//textarea[@id='other']");
			public static By objHomePh = By.xpath("//input[@id='phone']");
			public static By objMobile = By.xpath("//input[@id='phone_mobile']");
			public static By objFutureRefe = By.xpath("//input[@id='alias']");
			public static By objRegButton = By
					.xpath("//body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/form[1]/div[4]/button[1]/span[1]");
	     
		 
		 
			
			
			
			
			
			
			
	     
	     
	     
	     


}
