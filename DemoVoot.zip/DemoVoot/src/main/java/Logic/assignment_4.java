package Logic;

import static Logic.LaunchBrowsers.driver;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

import Pages.assignment4_page;






/*
 * working with the iframes i.e single iframe and iframe with fiframe

http://demo.automationtesting.in/Frames.html
 * */
 

public class assignment_4 {
	
	
	
	public static void single_frame() throws InterruptedException {
		
		String Parent_Window = driver.getWindowHandle();    

		System.out.println("switching");

		
		 WebElement frameCSSPath = driver.findElement(assignment4_page.pre_single_frame);
         driver.switchTo().frame(frameCSSPath);
         

		//driver.switchTo().frame(0);
		//Thread.sleep(3000);



		//Now we can click the button
		//driver.findElement(By.xpath("//input[@type='text']")).click();

		Thread.sleep(3000);
		System.out.println("switched");

		driver.findElement(assignment4_page.pre_single_frame_input).sendKeys("naresh_venkat");
		Thread.sleep(3000);
		
		driver.switchTo().window(Parent_Window);
		//Switch to the frame
		 //driver.switchTo().frame(0);
		 Thread.sleep(3000);
		 
		 
		 
		 
		 //clicking on iframe button
		 driver.findElement(assignment4_page.iframe_iframe_button).click();
		 //Thread.sleep(1000);

		

		 WebElement mframexparth = driver.findElement(assignment4_page.nested_iframe_parent_xpath);
        driver.switchTo().frame(mframexparth);
        
        
        
        WebElement sframexparth = driver.findElement(assignment4_page.nested_iframe_child_xpath);
        driver.switchTo().frame(sframexparth);
        
        //
		
		 Thread.sleep(3000);
		 System.out.println("clicked on iframe input");

		 driver.findElement(assignment4_page.nested_iframe_input_xpath).sendKeys("naresh_venkat");
		 Thread.sleep(3000);
			
		
		
	}
	

	
}
